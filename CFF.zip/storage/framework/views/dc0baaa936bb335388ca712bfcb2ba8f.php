<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Settings</h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6">
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6 relative">
                <?php if(session('status')): ?>
                    <div class="mb-4 text-green-700 bg-green-100 border border-green-200 px-4 py-2 rounded"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <form id="settingsForm" method="POST" action="<?php echo e(route('settings.update')); ?>" class="space-y-6">
                    <?php echo csrf_field(); ?>
                    <div class="space-y-1">
                        <label class="block text-sm font-medium text-gray-700">Monthly Subscription Amount</label>
                        <input type="number" step="0.01" name="monthly_subscription_amount" value="<?php echo e(old('monthly_subscription_amount', optional($settings)->monthly_subscription_amount)); ?>" class="mt-1 block w-full border rounded px-3 py-2" required>
                        <?php $__errorArgs = ['monthly_subscription_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="space-y-1">
                        <label class="block text-sm font-medium text-gray-700">Fine Amount</label>
                        <input type="number" step="0.01" name="fine_amount" value="<?php echo e(old('fine_amount', optional($settings)->fine_amount)); ?>" class="mt-1 block w-full border rounded px-3 py-2" required>
                        <?php $__errorArgs = ['fine_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <!-- Top Save button for quick access -->
                    <div class="flex justify-end gap-3">
                        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">Save</button>
                    </div>
                </form>
                
                <!-- Sticky bottom action bar to ensure Save is always visible -->
                <div class="sticky bottom-0 left-0 right-0 mt-6 -mx-6 px-6 py-3 bg-white/80 backdrop-blur border-t flex items-center justify-end">
                    <button form="settingsForm" type="submit" class="bg-blue-600 text-white px-5 py-2 rounded shadow">Save</button>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\CFF\resources\views/settings/index.blade.php ENDPATH**/ ?>