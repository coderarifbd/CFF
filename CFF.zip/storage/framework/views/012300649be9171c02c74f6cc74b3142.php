<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Deposits</h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6" x-data="{ modalOpen: <?php echo e($errors->any() ? 'true' : 'false'); ?> }" x-effect="if(modalOpen){ window.dispatchEvent(new CustomEvent('modal-opened')); }">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <div class="flex items-center justify-between gap-2 mb-4 flex-wrap">
                    <form method="GET" action="<?php echo e(route('deposits.index')); ?>" class="flex items-center gap-2 flex-wrap">
                        <select name="member_id" class="border rounded px-3 py-2">
                            <option value="">All Members</option>
                            <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($m->id); ?>" <?php if(request('member_id')==$m->id): echo 'selected'; endif; ?>><?php echo e($m->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <select name="type" class="border rounded px-3 py-2">
                            <option value="">All Types</option>
                            <option value="subscription" <?php if(request('type')==='subscription'): echo 'selected'; endif; ?>>Subscription</option>
                            <option value="extra" <?php if(request('type')==='extra'): echo 'selected'; endif; ?>>Extra</option>
                            <option value="fine" <?php if(request('type')==='fine'): echo 'selected'; endif; ?>>Fine</option>
                        </select>
                        <select name="month" class="border rounded px-3 py-2">
                            <option value="">Month</option>
                            <?php for($m=1;$m<=12;$m++): ?>
                                <option value="<?php echo e($m); ?>" <?php if(request('month')==$m): echo 'selected'; endif; ?>><?php echo e(date('F', mktime(0,0,0,$m,1))); ?></option>
                            <?php endfor; ?>
                        </select>
                        <select name="year" class="border rounded px-3 py-2">
                            <option value="">Year</option>
                            <?php for($y=2019;$y<=date('Y')+1;$y++): ?>
                                <option value="<?php echo e($y); ?>" <?php if(request('year')==$y): echo 'selected'; endif; ?>><?php echo e($y); ?></option>
                            <?php endfor; ?>
                        </select>
                        <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Search member" class="border rounded px-3 py-2">
                        <button class="bg-blue-600 text-white px-4 py-2 rounded">Filter</button>
                    </form>

                    <?php if(auth()->guard()->check()): ?>
                    <button type="button" @click="modalOpen = true; $nextTick(()=>window.dispatchEvent(new CustomEvent('modal-opened')));" class="bg-green-600 text-white px-4 py-2 rounded">+ Add Deposit</button>
                    <?php endif; ?>
                </div>

                <div class="mb-4 text-xs text-gray-600">
                    Logged in as: <strong><?php echo e(auth()->user()->email ?? 'guest'); ?></strong>
                    <?php if(auth()->check()): ?>
                        | Roles: <?php echo e(implode(', ', auth()->user()->getRoleNames()->toArray()) ?: 'none'); ?>

                    <?php endif; ?>
                </div>

                <?php if(session('status')): ?>
                    <div class="mb-4 text-green-700 bg-green-100 border border-green-200 px-4 py-2 rounded"><?php echo e(session('status')); ?></div>
                <?php endif; ?>

                <div class="overflow-x-auto">
                    <table class="min-w-full table-auto border-separate border-spacing-0">
                        <thead class="sticky top-0">
                            <tr class="bg-gray-50 text-left">
                                <th class="px-4 py-2">Date</th>
                                <th class="px-4 py-2">Member</th>
                                <th class="px-4 py-2">Breakdown</th>
                                <th class="px-4 py-2">Total</th>
                                <th class="px-4 py-2">Method</th>
                                <th class="px-4 py-2">Added By</th>
                                <th class="px-4 py-2">Note</th>
                                <th class="px-4 py-2">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $receipts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="border-t odd:bg-white even:bg-gray-50 hover:bg-gray-100">
                                    <td class="px-4 py-2"><?php echo e($r->date->format('Y-m-d')); ?></td>
                                    <td class="px-4 py-2"><?php echo e($r->member->name ?? '—'); ?></td>
                                    <td class="px-4 py-2">
                                        <div class="flex flex-wrap gap-2">
                                            <?php
                                                $map = [
                                                    'subscription' => ['Monthly', 'bg-blue-100 text-blue-800'],
                                                    'extra' => ['Extra', 'bg-gray-100 text-gray-800'],
                                                    'fine' => ['Fine', 'bg-red-100 text-red-800'],
                                                ];
                                            ?>
                                            <?php $__currentLoopData = $r->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    [$label, $style] = $map[$it->type];
                                                ?>
                                                <span class="px-2 py-1 rounded text-xs <?php echo e($style); ?>"><?php echo e($label); ?>: <?php echo e(number_format($it->amount,2)); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </td>
                                    <td class="px-4 py-2 font-semibold"><?php echo e(number_format($r->total_amount,2)); ?></td>
                                    <td class="px-4 py-2 capitalize"><?php echo e($r->payment_method); ?></td>
                                    <td class="px-4 py-2"><?php echo e($r->addedBy->name ?? '-'); ?></td>
                                    <td class="px-4 py-2"><?php echo e($r->note); ?></td>
                                    <td class="px-4 py-2">
                                        <?php if(auth()->check() && auth()->user()->hasRole('Admin')): ?>
                                        <div class="flex items-center gap-3">
                                            <a href="<?php echo e(route('deposits.edit', $r->id)); ?>" class="text-indigo-700 hover:underline">Edit</a>
                                            <form action="<?php echo e(route('deposits.destroy', $r->id)); ?>" method="POST" onsubmit="return confirm('Delete this deposit?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="text-red-700 hover:underline">Delete</button>
                                            </form>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="7" class="px-4 py-6 text-center text-gray-500">No deposits found.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                        <tfoot>
                            <tr class="border-t">
                                <td class="px-4 py-2 font-semibold" colspan="3">Totals</td>
                                <td class="px-4 py-2 font-semibold"><?php echo e(number_format($totalAmount,2)); ?></td>
                                <td class="px-4 py-2 font-semibold">&nbsp;</td>
                                <td class="px-4 py-2 font-semibold">Fines: <?php echo e(number_format($fineTotal,2)); ?></td>
                                <td class="px-4 py-2"></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <div class="mt-4"><?php echo e($receipts->links()); ?></div>
            </div>
        </div>

        <!-- Add Deposit Modal -->
        <div x-show="modalOpen" x-cloak class="fixed inset-0 z-50 flex items-center justify-center">
            <div class="absolute inset-0 bg-black/50" @click="modalOpen=false"></div>
            <div class="relative bg-white w-full max-w-2xl mx-auto rounded shadow-lg" x-data='{
                    types: <?php echo e(json_encode(old("types", []))); ?>,
                }'>
                <div class="px-5 py-4 border-b flex items-center justify-between">
                    <h3 class="font-semibold text-lg">Add Deposit</h3>
                    <button class="text-gray-600" @click="modalOpen=false">✕</button>
                </div>
                <div class="p-5">
                    <form method="POST" action="<?php echo e(route('deposits.store')); ?>" class="space-y-4">
                        <?php echo csrf_field(); ?>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Date</label>
                                <input type="date" name="date" value="<?php echo e(old('date', now()->toDateString())); ?>" class="mt-1 w-full border rounded px-3 py-2" required>
                                <?php $__errorArgs = ['date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Member</label>
                                <select name="member_id" id="modal_member_id" class="mt-1 w-full border rounded px-3 py-2" required>
                                    <option value="">Select member</option>
                                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($m->id); ?>" <?php if(old('member_id')==$m->id): echo 'selected'; endif; ?>><?php echo e($m->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['member_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div id="modal_deposit_history" class="hidden mt-3">
                            <div class="flex items-center justify-between mb-2">
                                <h4 class="text-sm font-semibold text-gray-700">Last 12 Months</h4>
                                <div class="flex items-center gap-2">
                                    <button type="button" id="modal_hist_prev" class="px-2 py-1 rounded border text-xs">‹</button>
                                    <button type="button" id="modal_hist_next" class="px-2 py-1 rounded border text-xs">›</button>
                                </div>
                            </div>
                            <div class="overflow-x-auto">
                                <div id="modal_hist_track" class="flex gap-2 min-w-max"></div>
                            </div>
                            <p class="mt-2 text-xs text-gray-500">Green = Paid subscription. Red = Due (no subscription recorded).</p>
                        </div>

                        <div id="modal_last_month_summary" class="hidden mt-2">
                            <div class="rounded-lg border border-gray-200 p-4 bg-gray-50">
                                <div class="flex items-center justify-between gap-3 mb-3 flex-wrap">
                                    <div class="flex items-center gap-2">
                                        <h3 class="text-sm font-semibold text-gray-700">Payment Summary</h3>
                                        <span id="modal_lms_period" class="text-xs text-gray-500"></span>
                                    </div>
                                    <div class="flex items-center gap-2">
                                        <button type="button" id="modal_lms_prev" class="px-2 py-1 rounded border text-xs">Prev</button>
                                        <select id="modal_lms_month" class="border rounded px-2 py-1 text-sm">
                                            <option value="1">Jan</option>
                                            <option value="2">Feb</option>
                                            <option value="3">Mar</option>
                                            <option value="4">Apr</option>
                                            <option value="5">May</option>
                                            <option value="6">Jun</option>
                                            <option value="7">Jul</option>
                                            <option value="8">Aug</option>
                                            <option value="9">Sep</option>
                                            <option value="10">Oct</option>
                                            <option value="11">Nov</option>
                                            <option value="12">Dec</option>
                                        </select>
                                        <select id="modal_lms_year" class="border rounded px-2 py-1 text-sm"></select>
                                        <button type="button" id="modal_lms_next" class="px-2 py-1 rounded border text-xs">Next</button>
                                    </div>
                                </div>
                                <div class="grid grid-cols-3 gap-3 text-sm">
                                    <div>
                                        <p class="text-gray-500">Subscription</p>
                                        <p id="modal_lms_sub" class="font-semibold tabular-nums">—</p>
                                    </div>
                                    <div>
                                        <p class="text-gray-500">Extra</p>
                                        <p id="modal_lms_extra" class="font-semibold tabular-nums">—</p>
                                    </div>
                                    <div>
                                        <p class="text-gray-500">Fine</p>
                                        <p id="modal_lms_fine" class="font-semibold tabular-nums">—</p>
                                    </div>
                                </div>
                                <div class="mt-3 text-right text-sm">
                                    <span class="text-gray-600">Total: </span>
                                    <span id="modal_lms_total" class="font-semibold tabular-nums">—</span>
                                </div>
                            </div>
                        </div>

                        <div class="space-y-3">
                            <label class="block text-sm font-medium text-gray-700">Type</label>
                            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                                <label class="inline-flex items-center gap-2">
                                    <input type="checkbox" class="rounded border-gray-300" value="subscription" x-model="types" name="types[]">
                                    <span>Monthly Subscription</span>
                                </label>
                                <label class="inline-flex items-center gap-2">
                                    <input type="checkbox" class="rounded border-gray-300" value="extra" x-model="types" name="types[]">
                                    <span>Extra Deposit</span>
                                </label>
                                <label class="inline-flex items-center gap-2">
                                    <input type="checkbox" class="rounded border-gray-300" value="fine" x-model="types" name="types[]">
                                    <span>Fine</span>
                                </label>
                            </div>
                            <?php $__errorArgs = ['types'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div x-show="types.includes('subscription')" x-cloak>
                                <label class="block text-sm font-medium text-gray-700">Subscription Amount</label>
                                <input type="number" step="0.01" name="amount_subscription" value="<?php echo e(old('amount_subscription', $subscriptionAmount)); ?>" class="mt-1 w-full border rounded px-3 py-2" :required="types.includes('subscription')">
                            </div>
                            <div x-show="types.includes('extra')" x-cloak>
                                <label class="block text-sm font-medium text-gray-700">Extra Amount</label>
                                <input type="number" step="0.01" name="amount_extra" value="<?php echo e(old('amount_extra')); ?>" class="mt-1 w-full border rounded px-3 py-2" :required="types.includes('extra')">
                            </div>
                            <div x-show="types.includes('fine')" x-cloak>
                                <label class="block text-sm font-medium text-gray-700">Fine Amount</label>
                                <input type="number" step="0.01" name="amount_fine" value="<?php echo e(old('amount_fine', $fineAmount)); ?>" class="mt-1 w-full border rounded px-3 py-2" :required="types.includes('fine')">
                            </div>
                        </div>
                        <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-600 text-sm"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Payment Method</label>
                                <select name="payment_method" class="mt-1 w-full border rounded px-3 py-2" required>
                                    <option value="cash" <?php if(old('payment_method')==='cash'): echo 'selected'; endif; ?>>Cash</option>
                                    <option value="bank" <?php if(old('payment_method')==='bank'): echo 'selected'; endif; ?>>Bank</option>
                                    <option value="mobile" <?php if(old('payment_method')==='mobile'): echo 'selected'; endif; ?>>Mobile Banking</option>
                                </select>
                                <?php $__errorArgs = ['payment_method'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Note (optional)</label>
                                <input type="text" name="note" value="<?php echo e(old('note')); ?>" class="mt-1 w-full border rounded px-3 py-2">
                                <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="flex items-center justify-end gap-3 pt-2">
                            <button type="button" @click="modalOpen=false" class="px-4 py-2 border rounded">Cancel</button>
                            <button class="px-4 py-2 bg-green-600 text-white rounded">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    (function(){
        const sel = document.getElementById('modal_member_id');
        if(!sel) return;
        const box = document.getElementById('modal_last_month_summary');
        const hist = { box: document.getElementById('modal_deposit_history'), track: document.getElementById('modal_hist_track'), prev: document.getElementById('modal_hist_prev'), next: document.getElementById('modal_hist_next') };
        const el = {
            period: document.getElementById('modal_lms_period'),
            sub: document.getElementById('modal_lms_sub'),
            extra: document.getElementById('modal_lms_extra'),
            fine: document.getElementById('modal_lms_fine'),
            total: document.getElementById('modal_lms_total'),
            month: document.getElementById('modal_lms_month'),
            year: document.getElementById('modal_lms_year'),
            prev: document.getElementById('modal_lms_prev'),
            next: document.getElementById('modal_lms_next'),
        };
        const fmt = (n)=> new Intl.NumberFormat(undefined,{minimumFractionDigits:2, maximumFractionDigits:2}).format(n||0);
        function setDefaultPeriod(){
            const now = new Date();
            const d = new Date(now.getFullYear(), now.getMonth()-1, 1);
            if(el.month) el.month.value = String(d.getMonth()+1);
            if(el.year && el.year.options.length===0){
                const start = now.getFullYear()-5, end = now.getFullYear()+1;
                for(let y=start;y<=end;y++){ const opt=document.createElement('option'); opt.value=String(y); opt.textContent=String(y); el.year.appendChild(opt);} }
            if(el.year) el.year.value = String(d.getFullYear());
        }
        async function loadSummary(){
            const memberId = sel.value; if(!memberId){ box.classList.add('hidden'); return; }
            const month = el.month ? el.month.value : ''; const year = el.year ? el.year.value : '';
            try{
                const q = new URLSearchParams({ member_id: memberId }); if(month) q.set('month', month); if(year) q.set('year', year);
                const res = await fetch(`<?php echo e(route('deposits.last-month')); ?>?${q.toString()}`, { headers: { 'X-Requested-With':'XMLHttpRequest' }});
                if(!res.ok) throw new Error('Last-month fetch failed: '+res.status);
                const d = await res.json();
                if(el.period) el.period.textContent = `${d.year}-${String(d.month).padStart(2,'0')}`;
                if(el.sub) el.sub.textContent = fmt(d.subscription);
                if(el.extra) el.extra.textContent = fmt(d.extra);
                if(el.fine) el.fine.textContent = fmt(d.fine);
                if(el.total) el.total.textContent = fmt(d.total);
                box.classList.remove('hidden');
            }catch(e){ console.error(e); box.classList.add('hidden'); }
        }
        async function loadHistory(){
            const memberId = sel.value; if(!memberId){ hist.box.classList.add('hidden'); return; }
            try{
                const res = await fetch(`<?php echo e(route('deposits.history')); ?>?member_id=${memberId}&months=12`, { headers: { 'X-Requested-With':'XMLHttpRequest' }});
                if(!res.ok) throw new Error('History fetch failed: '+res.status);
                const data = await res.json();
                hist.track.innerHTML='';
                (data.items||[]).forEach(item=>{
                    const card=document.createElement('div');
                    card.className = `rounded-lg border px-3 py-2 text-xs w-28 ${item.due ? 'border-red-200 bg-red-50' : 'border-emerald-200 bg-emerald-50'}`;
                    card.innerHTML = `<div class=\"font-semibold\">${item.label}</div>
                                      <div>Sub: <span class=\"tabular-nums\">${fmt(item.subscription)}</span></div>`;
                    hist.track.appendChild(card);
                });
                hist.box.classList.remove('hidden');
            }catch(e){ console.error(e); hist.box.classList.add('hidden'); }
        }
        function bindNav(){
            const sc = document.getElementById('modal_deposit_history').querySelector('.overflow-x-auto');
            hist.prev && hist.prev.addEventListener('click', ()=> sc.scrollBy({ left: -200, behavior: 'smooth' }));
            hist.next && hist.next.addEventListener('click', ()=> sc.scrollBy({ left: +200, behavior: 'smooth' }));
            el.month && el.month.addEventListener('change', loadSummary);
            el.year && el.year.addEventListener('change', loadSummary);
            el.prev && el.prev.addEventListener('click', ()=>{
                const m=parseInt(el.month.value,10); let y=parseInt(el.year.value,10); let nm=m-1; if(nm<1){ nm=12; y=y-1; }
                el.month.value=String(nm); el.year.value=String(y); loadSummary();
            });
            el.next && el.next.addEventListener('click', ()=>{
                const m=parseInt(el.month.value,10); let y=parseInt(el.year.value,10); let nm=m+1; if(nm>12){ nm=1; y=y+1; }
                el.month.value=String(nm); el.year.value=String(y); loadSummary();
            });
        }
        setDefaultPeriod();
        if(sel && sel.value){ loadSummary(); loadHistory(); }
        sel.addEventListener('change', ()=>{ loadSummary(); loadHistory(); });
        bindNav();
        // If using Alpine modalOpen flag, refresh when the modal opens
        document.addEventListener('alpine:init', () => {
            document.addEventListener('modal-opened', () => { if(sel.value){ loadSummary(); loadHistory(); } });
        });
    })();
</script>
<?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\CFF\resources\views/deposits/index.blade.php ENDPATH**/ ?>