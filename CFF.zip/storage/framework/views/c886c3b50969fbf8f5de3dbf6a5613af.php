<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">Edit Deposit</h2>
     <?php $__env->endSlot(); ?>

    <div class="py-6" x-data='{
        types: <?php echo json_encode($receipt->items->pluck("type"), 15, 512) ?>,
    }'>
        <div class="max-w-3xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <?php if($errors->any()): ?>
                    <div class="mb-4 text-red-700 bg-red-100 border border-red-200 px-4 py-2 rounded">
                        <ul class="list-disc ms-5">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="<?php echo e(route('deposits.update', $receipt->id)); ?>" class="space-y-4">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Date</label>
                            <input type="date" name="date" value="<?php echo e(old('date', $receipt->date->toDateString())); ?>" class="mt-1 w-full border rounded px-3 py-2" required>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Member</label>
                            <select name="member_id" class="mt-1 w-full border rounded px-3 py-2" required>
                                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($m->id); ?>" <?php if(old('member_id', $receipt->member_id)==$m->id): echo 'selected'; endif; ?>><?php echo e($m->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Payment Method</label>
                            <select name="payment_method" class="mt-1 w-full border rounded px-3 py-2" required>
                                <option value="cash" <?php if(old('payment_method',$receipt->payment_method)==='cash'): echo 'selected'; endif; ?>>Cash</option>
                                <option value="bank" <?php if(old('payment_method',$receipt->payment_method)==='bank'): echo 'selected'; endif; ?>>Bank</option>
                                <option value="mobile" <?php if(old('payment_method',$receipt->payment_method)==='mobile'): echo 'selected'; endif; ?>>Mobile Banking</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-medium text-gray-700">Note (optional)</label>
                            <input type="text" name="note" value="<?php echo e(old('note', $receipt->note)); ?>" class="mt-1 w-full border rounded px-3 py-2">
                        </div>
                    </div>

                    <div class="space-y-3">
                        <label class="block text-sm font-medium text-gray-700">Type</label>
                        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                            <label class="inline-flex items-center gap-2">
                                <input type="checkbox" class="rounded border-gray-300" value="subscription" x-model="types" name="types[]">
                                <span>Monthly Subscription</span>
                            </label>
                            <label class="inline-flex items-center gap-2">
                                <input type="checkbox" class="rounded border-gray-300" value="extra" x-model="types" name="types[]">
                                <span>Extra Deposit</span>
                            </label>
                            <label class="inline-flex items-center gap-2">
                                <input type="checkbox" class="rounded border-gray-300" value="fine" x-model="types" name="types[]">
                                <span>Fine</span>
                            </label>
                        </div>
                        <?php $__errorArgs = ['types'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-600 text-sm mt-1"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <?php
                        $amounts = [
                            'subscription' => old('amount_subscription', optional($receipt->items->firstWhere('type','subscription'))->amount ?? $subscriptionAmount),
                            'extra' => old('amount_extra', optional($receipt->items->firstWhere('type','extra'))->amount ?? ''),
                            'fine' => old('amount_fine', optional($receipt->items->firstWhere('type','fine'))->amount ?? $fineAmount),
                        ];
                    ?>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div x-show="types.includes('subscription')" x-cloak>
                            <label class="block text-sm font-medium text-gray-700">Subscription Amount</label>
                            <input type="number" step="0.01" name="amount_subscription" value="<?php echo e($amounts['subscription']); ?>" class="mt-1 w-full border rounded px-3 py-2" :required="types.includes('subscription')">
                        </div>
                        <div x-show="types.includes('extra')" x-cloak>
                            <label class="block text-sm font-medium text-gray-700">Extra Amount</label>
                            <input type="number" step="0.01" name="amount_extra" value="<?php echo e($amounts['extra']); ?>" class="mt-1 w-full border rounded px-3 py-2" :required="types.includes('extra')">
                        </div>
                        <div x-show="types.includes('fine')" x-cloak>
                            <label class="block text-sm font-medium text-gray-700">Fine Amount</label>
                            <input type="number" step="0.01" name="amount_fine" value="<?php echo e($amounts['fine']); ?>" class="mt-1 w-full border rounded px-3 py-2" :required="types.includes('fine')">
                        </div>
                    </div>

                    <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><p class="text-red-600 text-sm"><?php echo e($message); ?></p><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    <div class="flex items-center justify-end gap-3 pt-2">
                        <a href="<?php echo e(route('deposits.index')); ?>" class="px-4 py-2 border rounded">Cancel</a>
                        <button class="px-4 py-2 bg-green-600 text-white rounded">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\CFF\resources\views/deposits/receipt_edit.blade.php ENDPATH**/ ?>