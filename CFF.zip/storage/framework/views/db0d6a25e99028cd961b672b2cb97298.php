<div class="overflow-x-auto">
    <table class="min-w-full text-sm">
        <thead>
            <tr class="text-left">
                <th class="px-3 py-2">Date</th>
                <th class="px-3 py-2">Category</th>
                <th class="px-3 py-2">Note</th>
                <th class="px-3 py-2 text-right">Amount</th>
                <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'Admin|Accountant')): ?>
                <th class="px-3 py-2 text-right">Actions</th>
                <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $incomes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t">
                    <td class="px-3 py-2"><?php echo e(\Illuminate\Support\Carbon::parse($inc->date)->format('Y-m-d')); ?></td>
                    <td class="px-3 py-2"><?php echo e($inc->category); ?></td>
                    <td class="px-3 py-2"><?php echo e($inc->note); ?></td>
                    <td class="px-3 py-2 text-right"><?php echo e(number_format($inc->amount, 2)); ?></td>
                    <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'Admin|Accountant')): ?>
                    <td class="px-3 py-2 text-right">
                        <div class="inline-flex items-center gap-2">
                            <a href="<?php echo e(route('other-incomes.edit', $inc)); ?>" class="px-2 py-1 text-indigo-600 hover:underline">Edit</a>
                            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
                            <form method="POST" action="<?php echo e(route('other-incomes.destroy', $inc)); ?>" onsubmit="return confirm('Delete this income?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="px-2 py-1 text-red-600 hover:underline">Delete</button>
                            </form>
                            <?php endif; ?>
                        </div>
                    </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="px-3 py-6 text-center text-gray-500">No records</td>
                </tr>
            <?php endif; ?>
        </tbody>
        <tfoot>
            <tr class="border-t font-semibold">
                <td colspan="3" class="px-3 py-2 text-right">Total</td>
                <td class="px-3 py-2 text-right"><?php echo e(number_format($total, 2)); ?></td>
                <?php if (\Illuminate\Support\Facades\Blade::check('hasanyrole', 'Admin|Accountant')): ?>
                <td></td>
                <?php endif; ?>
            </tr>
        </tfoot>
    </table>
</div>

<div class="mt-4"><?php echo e($incomes->links()); ?></div>
<?php /**PATH C:\laragon\www\CFF\resources\views/other_incomes/partials/table.blade.php ENDPATH**/ ?>